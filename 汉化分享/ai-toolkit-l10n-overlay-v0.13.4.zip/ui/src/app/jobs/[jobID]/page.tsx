'use client';

import { useState, use } from 'react';
import { FaChevronLeft } from 'react-icons/fa';
import { MdDashboard, MdImage, MdShowChart, MdCode, MdExtension } from 'react-icons/md';
import { Button } from '@headlessui/react';
import { TopBar, MainContent } from '@/components/layout';
import useJob from '@/hooks/useJob';
import usePollLoop from '@/hooks/usePollLoop';
import SampleImages, { SampleImagesMenu } from '@/components/SampleImages';
import JobOverview from '@/components/JobOverview';
import { redirect } from 'next/navigation';
import JobActionBar from '@/components/JobActionBar';
import JobConfigViewer from '@/components/JobConfigViewer';
import JobLossGraph from '@/components/JobLossGraph';
import JobPlugin from '@/components/JobPlugin';
import { Job } from '@prisma/client';
import { apiClient } from '@/utils/api';

type PageKey = 'overview' | 'samples' | 'config' | 'loss_log' | 'plugin';

interface Page {
  name: string;
  value: PageKey;
  icon: React.ComponentType<{ className?: string }>;
  component: React.ComponentType<{ job: Job }>;
  menuItem?: React.ComponentType<{ job?: Job | null }> | null;
  mainCss?: string;
  jobTypes?: string[]; // if specified, only show this page for these job types
}

const pages: Page[] = [
  {
    name: '概览 (Overview)',
    value: 'overview',
    icon: MdDashboard,
    component: JobOverview,
    mainCss: 'pt-24',
  },
  {
    name: '样本 (Samples)',
    value: 'samples',
    icon: MdImage,
    component: SampleImages,
    menuItem: SampleImagesMenu,
    mainCss: 'pt-24',
    jobTypes: ['train'],
  },
  {
    name: '损失曲线 (Loss Graph)',
    value: 'loss_log',
    icon: MdShowChart,
    component: JobLossGraph,
    mainCss: 'pt-24 pb-4',
    jobTypes: ['train'],
  },
  {
    name: '配置文件 (Config File)',
    value: 'config',
    icon: MdCode,
    component: JobConfigViewer,
    mainCss: 'pt-[80px] px-0 pb-0',
  },
  {
    name: '插件 (Plugin)',
    value: 'plugin',
    icon: MdExtension,
    component: JobPlugin,
    mainCss: 'pt-[80px] px-0 pb-0',
  },
];

export default function JobPage({ params }: { params: { jobID: string } }) {
  const usableParams = use(params as any) as { jobID: string };
  const jobID = usableParams.jobID;
  const { job, status, refreshJob } = useJob(jobID, 5000);
  const [pageKey, setPageKey] = useState<PageKey>('overview');
  const [hasPlugin, setHasPlugin] = useState(false);

  // poll for plugin.html in the job folder; show the Plugin tab if it exists
  usePollLoop(
    () =>
      apiClient
        .get(`/api/jobs/${jobID}/plugin?check=1`)
        .then(res => res.data)
        .then(data => setHasPlugin(!!data.exists))
        .catch(() => {}),
    5000,
    [jobID],
  );

  const page = pages.find(p => p.value === pageKey);

  const jobType = job?.job_type || 'unknown';

  let title = `任务: ${job?.name || '加载中 (Loading...)'}`;
  if (jobType === 'caption') {
    title = `标注中: ${job?.job_ref || '加载中 (Loading...)'}`;
  }

  return (
    <>
      {/* Fixed top bar */}
      <TopBar>
        <div className="flex-shrink-0">
          <Button className="text-gray-500 dark:text-gray-300 pl-0 pr-1 sm:px-3 mt-1" onClick={() => redirect('/jobs')}>
            <FaChevronLeft />
          </Button>
        </div>
        <div className="min-w-0 flex-shrink">
          <h1 className="text-base sm:text-lg truncate">{title}</h1>
        </div>
        <div className="flex-1"></div>
        {job && (
          <JobActionBar
            job={job}
            onRefresh={refreshJob}
            hideView
            afterDelete={() => {
              redirect('/jobs');
            }}
            autoStartQueue={true}
          />
        )}
      </TopBar>
      <MainContent className={pages.find(page => page.value === pageKey)?.mainCss}>
        {status === 'loading' && job == null && <p>加载中 (Loading...)</p>}
        {status === 'error' && job == null && <p>获取任务出错 (Error fetching job)</p>}
        {job && (
          <>
            {pages.map(page => {
              const Component = page.component;
              return page.value === pageKey ? <Component key={page.value} job={job} /> : null;
            })}
          </>
        )}
      </MainContent>
      <div className="bg-gray-800 absolute top-12 left-0 w-full h-8 flex items-center px-0 sm:px-2 text-sm sm:overflow-x-auto whitespace-nowrap">
        {pages.map(page => {
          if (page.jobTypes && !page.jobTypes.includes(jobType)) {
            return null;
          }
          if (page.value === 'plugin' && !hasPlugin) {
            return null;
          }
          return (
            <Button
              key={page.value}
              onClick={() => setPageKey(page.value)}
              className={`flex-1 sm:flex-initial justify-center px-2 sm:px-4 py-1 h-8 flex items-center gap-1.5 sm:flex-shrink-0 ${page.value === pageKey ? 'bg-gray-300 dark:bg-gray-700 text-white' : ''}`}
            >
              <page.icon className="text-sm" />
              <span className="hidden sm:inline">{page.name}</span>
            </Button>
          );
        })}
        {page?.menuItem && (
          <>
            <div className="hidden sm:block flex-grow"></div>
            <page.menuItem job={job} />
          </>
        )}
      </div>
    </>
  );
}
